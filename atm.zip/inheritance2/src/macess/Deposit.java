package macess;

public class Deposit implements Transaction  {
public void process (int amt) {
	System.out.println("amt deposited ;"+amt);
	b.bal=b.bal+amt;
	System.out.println("balance amt:"+b.getBalance());
	System.out.println("transaction completed...");
	
}
	
}
