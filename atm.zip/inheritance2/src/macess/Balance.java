package macess;

public class Balance {
	public double bal = 2000 ;
	public double getBalance()	{
		return bal;
		
	}

}
