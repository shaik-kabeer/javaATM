package macess;

 public class Withdraw implements Transaction {
 public void process (int amt){
if (amt<b.bal) {
	

	 System.out.println("amt withdrawn :"+amt);
 b.bal=b.bal-amt ;
System.out.println("balance amt:"+b.getBalance());
System.out.println("transaction completed...");
}
else
{System.out.println ("in suffient fund...");

}
 }
 }

