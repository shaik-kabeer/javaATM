package test;
import macess.*;
import java.util.*;

public class BankMainClass {

	public static void main(String[] args) {
  Scanner s = new Scanner (System.in);
  int count=0;
  pqr: 
	  while (true) {
		  System.out.println("enter the pin no:");
		  int PinNo =s.nextInt();
		  CheckPinNo cpn =new CheckPinNo();
		  boolean k = cpn.verify(PinNo);
		  if (k)
{   System.out.println("====choice =====");
System.out.println("1.withdraw\n2.deposit\n3.check balance ");
			  System.out.println("enter the choice :");
			  switch(s.nextInt())
			  {
			  case 1 :
				  System.out.println("enter the amount:");
				 int a1=s.nextInt();
				 if(a1>0&&a1%100==0)
				 {
					 Withdraw wd = new Withdraw();
					 wd.process(a1);;
					 
				 }else
				 {
					 System.out.println("invaild amt..");
					 
				 }
				 break pqr;
				 
			  case 2:
				  System.out.println("enter the amt :");
				  int a2 =s.nextInt();
				  if (a2>0&&a2%100==0)
				  {
					  Deposit dp =new Deposit();
					  dp.process(a2);
					  
				  }
				  else {
					  System.out.println("invalid amt...");
				  }	  
	
				  break pqr ;
				  
			  
}	  }
			  
			  
			  else { 
				  System.out.println("invalid pinNo...");
				  count++;
				  
			  }
			  if (count==3)
			  {
				  System.out.println("transaction blocked ....");
				  break;
				  
				  
				  
				  
			  }
				  
			  }
	  
				  
}}